// import 'package:get/get.dart';
//
// class CarouselController extends GetxController {
//   // The current index of the carousel
//   var currentIndex = 0.obs;
//
//   void updateIndex(int index) {
//     currentIndex.value = index; // Update the current index
//   }
// }
