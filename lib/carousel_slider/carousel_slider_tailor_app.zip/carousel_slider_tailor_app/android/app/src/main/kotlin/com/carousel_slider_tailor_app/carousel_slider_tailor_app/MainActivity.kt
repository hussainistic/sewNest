package com.carousel_slider_tailor_app.carousel_slider_tailor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
